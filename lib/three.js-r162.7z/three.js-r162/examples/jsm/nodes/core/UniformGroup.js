class UniformGroup {

	constructor( name ) {

		this.name = name;

		this.isUniformGroup = true;

	}

}

export default UniformGroup;
